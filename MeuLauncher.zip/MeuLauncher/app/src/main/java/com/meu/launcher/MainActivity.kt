package com.meu.launcher

import android.app.Activity
import android.content.*
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.util.LruCache
import android.view.TextureView
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import java.time.format.TextStyle as JTextStyle

val CATS = listOf("Jogos", "Websites", "Social", "IA")
const val OTHERS = "Outros"
const val HIDDEN = "Oculto"
val EASE_BACK = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)

data class AppInfo(val pkg: String, val label: String)

data class Palette(
    val name: String, val bg: Color, val card: Color, val text: Color,
    val sub: Color, val accent: Color, val onAccent: Color
)

val THEMES = listOf(
    Palette("Branco", Color(0xFFF7F8FA), Color(0xFFFFFFFF), Color(0xFF111111), Color(0xFF777777), Color(0xFF111111), Color(0xFFFFFFFF)),
    Palette("Escuro", Color(0xFF0E0F12), Color(0xFF1C1D22), Color(0xFFF2F2F2), Color(0xFF9A9AA2), Color(0xFFFFFFFF), Color(0xFF111111)),
    Palette("Rosa", Color(0xFFFFF1F5), Color(0xFFFFFFFF), Color(0xFF3A1020), Color(0xFF9A6B7A), Color(0xFFE5487F), Color(0xFFFFFFFF)),
    Palette("Oceano", Color(0xFFEAF4FB), Color(0xFFFFFFFF), Color(0xFF0B2540), Color(0xFF5F7C99), Color(0xFF1E88E5), Color(0xFFFFFFFF)),
    Palette("Floresta", Color(0xFFEFF6EE), Color(0xFFFFFFFF), Color(0xFF12301C), Color(0xFF6A8A72), Color(0xFF2E9E5B), Color(0xFFFFFFFF)),
    Palette("Roxo", Color(0xFF16101F), Color(0xFF241A35), Color(0xFFF1E9FF), Color(0xFFA796C4), Color(0xFFB388FF), Color(0xFF1A1030)),
    Palette("Pôr do sol", Color(0xFFFFF4EA), Color(0xFFFFFFFF), Color(0xFF3B1D0A), Color(0xFF9A7458), Color(0xFFFF7A2F), Color(0xFFFFFFFF))
)

val ACCENTS = listOf(
    0xFF111111, 0xFFE5487F, 0xFFFF7A2F, 0xFFFFB400, 0xFF2E9E5B,
    0xFF1E88E5, 0xFF5B5BD6, 0xFFB388FF, 0xFFFFFFFF
).map { Color(it) }

val LocalPal = compositionLocalOf { THEMES[0] }

@Composable
fun animPal(t: Palette): Palette {
    val bg by animateColorAsState(t.bg, tween(450), label = "pbg")
    val card by animateColorAsState(t.card, tween(450), label = "pcard")
    val text by animateColorAsState(t.text, tween(450), label = "ptext")
    val sub by animateColorAsState(t.sub, tween(450), label = "psub")
    val accent by animateColorAsState(t.accent, tween(450), label = "pacc")
    val onAccent by animateColorAsState(t.onAccent, tween(450), label = "pon")
    return Palette(t.name, bg, card, text, sub, accent, onAccent)
}

class Music(
    val title: String, val artist: String, val art: ImageBitmap?, val playing: Boolean,
    val pos: Long, val dur: Long, val controller: MediaController
)

class MusicUi(val granted: Boolean, val music: Music?)

class ArtCache { var key = ""; var art: ImageBitmap? = null }

/** Serviço vazio: só serve para o Android liberar a leitura da música que está tocando. */
class MediaListener : NotificationListenerService()

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("launcher", 0)
    fun cat(pkg: String): String? = p.getString("c_$pkg", null)
    fun setCat(pkg: String, c: String?) =
        p.edit().apply { if (c == null) remove("c_$pkg") else putString("c_$pkg", c) }.apply()
    fun hidden(): Set<String> = p.getStringSet("hidden", emptySet())!!
    fun setHidden(pkg: String, h: Boolean) {
        val s = hidden().toMutableSet()
        if (h) s.add(pkg) else s.remove(pkg)
        p.edit().putStringSet("hidden", s).apply()
    }
    fun dock(): List<String> = (p.getString("dock", "") ?: "").split(",").filter { it.isNotEmpty() }
    fun setDock(l: List<String>) = p.edit().putString("dock", l.joinToString(",")).apply()
    fun kind(slot: String): String = p.getString("k_$slot", "") ?: ""
    fun setKind(slot: String, k: String) = p.edit().putString("k_$slot", k).apply()
    fun pin(): String = p.getString("pin", "1232") ?: "1232"
    fun theme(): Int = p.getInt("theme", 0)
    fun setTheme(i: Int) = p.edit().putInt("theme", i).apply()
    fun accent(): Int = p.getInt("accent", 0)
    fun setAccent(c: Int) = p.edit().putInt("accent", c).apply()
    fun dim(): Float = p.getFloat("dim", 0.35f)
    fun setDim(v: Float) = p.edit().putFloat("dim", v).apply()
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

object IconCache {
    private val c = LruCache<String, ImageBitmap>(200)
    fun get(ctx: Context, pkg: String): ImageBitmap =
        c[pkg] ?: ctx.packageManager.getApplicationIcon(pkg)
            .toBitmap(108, 108).asImageBitmap().also { c.put(pkg, it) }
}

fun launchApp(ctx: Context, pkg: String) {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) ctx.startActivity(i)
}

fun savePhoto(c: Context, u: Uri, name: String) {
    c.contentResolver.openInputStream(u)?.use { i ->
        File(c.filesDir, name).outputStream().use { i.copyTo(it) }
    }
}

fun loadPhoto(c: Context, name: String, max: Int): ImageBitmap? {
    val f = File(c.filesDir, name)
    if (!f.exists()) return null
    val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, b)
    var s = 1
    while (b.outWidth / s > max) s *= 2
    return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        ?.asImageBitmap()
}

/** Copia o arquivo escolhido (imagem, GIF/WebP animado ou vídeo) e devolve o tipo. */
fun saveMedia(c: Context, u: Uri, slot: String): String {
    val type = c.contentResolver.getType(u) ?: ""
    val kind = when {
        type.startsWith("video/") -> "video"
        type == "image/gif" || type == "image/webp" -> "anim"
        else -> "img"
    }
    c.contentResolver.openInputStream(u)?.use { i ->
        File(c.filesDir, "$slot.bin").outputStream().use { i.copyTo(it) }
    }
    return kind
}

@Composable
fun AnimView(file: File, rev: Int, active: Boolean, modifier: Modifier) {
    val d by produceState<Drawable?>(null, rev) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ImageDecoder.decodeDrawable(ImageDecoder.createSource(file)) { dec, info, _ ->
                    dec.setTargetSampleSize(maxOf(1, info.size.width / 900))
                }
            }.getOrNull()
        }
    }
    AndroidView(
        modifier = modifier,
        factory = { c -> ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
        update = { iv ->
            iv.setImageDrawable(d)
            val a = d as? AnimatedImageDrawable
            if (a != null) {
                a.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                if (active) a.start() else a.stop()
            }
        }
    )
}

@Composable
fun VideoBg(file: File, rev: Int, active: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    key(rev) {
        val exo = remember {
            ExoPlayer.Builder(ctx).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                repeatMode = Player.REPEAT_MODE_ALL
                volume = 0f
                prepare()
            }
        }
        var vs by remember { mutableStateOf(VideoSize.UNKNOWN) }
        DisposableEffect(exo) {
            val l = object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) { vs = videoSize }
            }
            exo.addListener(l)
            onDispose { exo.removeListener(l); exo.release() }
        }
        LaunchedEffect(exo, active) { exo.playWhenReady = active }
        BoxWithConstraints(modifier.clipToBounds()) {
            val cw = constraints.maxWidth.toFloat()
            val ch = constraints.maxHeight.toFloat()
            val s = if (vs.width > 0 && vs.height > 0) maxOf(cw / vs.width, ch / vs.height) else 1f
            val wPx = if (vs.width > 0) vs.width * s else cw
            val hPx = if (vs.height > 0) vs.height * s else ch
            val wDp = with(LocalDensity.current) { wPx.toDp() }
            val hDp = with(LocalDensity.current) { hPx.toDp() }
            AndroidView(
                modifier = Modifier.align(Alignment.Center).requiredSize(wDp, hDp),
                factory = { c -> TextureView(c).also { exo.setVideoTextureView(it) } }
            )
        }
    }
}

@Composable
fun MediaView(file: String, kind: String, rev: Int, active: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val f = File(ctx.filesDir, file)
    when (kind) {
        "img" -> {
            val bmp by produceState<ImageBitmap?>(null, rev) {
                value = withContext(Dispatchers.IO) { loadPhoto(ctx, file, 1200) }
            }
            bmp?.let { Image(it, null, modifier, contentScale = ContentScale.Crop) }
        }
        "anim" -> AnimView(f, rev, active, modifier)
        "video" -> VideoBg(f, rev, active, modifier)
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

fun readMusic(ctx: Context, cache: ArtCache): MusicUi {
    if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
        return MusicUi(false, null)
    }
    val c: MediaController? = try {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val l = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
        l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
    } catch (e: Exception) {
        null
    }
    if (c == null) return MusicUi(true, null)
    val m = c.metadata ?: return MusicUi(true, null)
    val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sem título"
    val key = c.packageName + "|" + title
    if (key != cache.key || cache.art == null) {
        cache.key = key
        cache.art = (m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART))?.asImageBitmap()
    }
    val st = c.playbackState
    val playing = st?.state == PlaybackState.STATE_PLAYING
    var pos = st?.position ?: 0L
    if (playing && st != null) {
        pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
    }
    val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
        ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
    val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
    return MusicUi(true, Music(title, artist, cache.art, playing, pos, dur, c))
}

@Composable
fun rememberMusic(ctx: Context): State<MusicUi> = produceState(MusicUi(true, null)) {
    val cache = ArtCache()
    while (true) {
        value = withContext(Dispatchers.Default) { readMusic(ctx, cache) }
        delay(1000)
    }
}

/** Marca quando um item (app, aba, botão) está sendo pressionado, para não abrir as configurações junto. */
object Guard { var pressing = false }

/** Entrada animada: sobe/desce com leve "quique" e aparece com fade. */
@Composable
fun Modifier.reveal(visible: Boolean, delayMs: Int = 0, fromY: Float = 60f): Modifier {
    val a by animateFloatAsState(
        if (visible) 1f else 0f, tween(450, delayMillis = delayMs), label = "a"
    )
    val y by animateFloatAsState(
        if (visible) 0f else fromY, tween(600, delayMillis = delayMs, easing = EASE_BACK), label = "y"
    )
    return this.graphicsLayer { alpha = a; translationY = y }
}

/** Efeito de apertar: encolhe e volta com mola. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.bounceClick(onLong: () -> Unit = {}, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.82f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "s"
    )
    DisposableEffect(pressed) {
        Guard.pressing = pressed
        onDispose { if (pressed) Guard.pressing = false }
    }
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src, indication = null,
            onClick = onClick, onLongClick = onLong
        )
}

@Composable
fun Glyph(kind: Int, sz: Dp, color: Color) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        when (kind) {
            0 -> drawPath(Path().apply {
                moveTo(w * .25f, h * .15f); lineTo(w * .85f, h * .5f); lineTo(w * .25f, h * .85f); close()
            }, color)
            1 -> {
                drawRect(color, Offset(w * .2f, h * .15f), Size(w * .2f, h * .7f))
                drawRect(color, Offset(w * .6f, h * .15f), Size(w * .2f, h * .7f))
            }
            2 -> {
                drawPath(Path().apply {
                    moveTo(w * .1f, h * .2f); lineTo(w * .65f, h * .5f); lineTo(w * .1f, h * .8f); close()
                }, color)
                drawRect(color, Offset(w * .72f, h * .2f), Size(w * .14f, h * .6f))
            }
            4 -> {
                drawCircle(color, w * .1f, Offset(w * .2f, h * .5f))
                drawCircle(color, w * .1f, Offset(w * .5f, h * .5f))
                drawCircle(color, w * .1f, Offset(w * .8f, h * .5f))
            }
            else -> {
                drawPath(Path().apply {
                    moveTo(w * .9f, h * .2f); lineTo(w * .35f, h * .5f); lineTo(w * .9f, h * .8f); close()
                }, color)
                drawRect(color, Offset(w * .14f, h * .2f), Size(w * .14f, h * .6f))
            }
        }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.Default) { runCatching { IconCache.get(ctx, pkg) }.getOrNull() }
    }
    val a by animateFloatAsState(if (icon != null) 1f else 0f, tween(300), label = "ia")
    Box(Modifier.size(size).graphicsLayer { alpha = a }) {
        icon?.let { Image(it, null, Modifier.fillMaxSize()) }
    }
}

@Composable
fun AppMenu(open: Boolean, onClose: () -> Unit, app: AppInfo, store: Store, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val isHidden = app.pkg in store.hidden()
    val dock = store.dock()
    DropdownMenu(open, onClose) {
        (CATS + OTHERS).forEach { c ->
            DropdownMenuItem(text = { Text("Mover para $c") }, onClick = {
                store.setCat(app.pkg, if (c == OTHERS) null else c); onClose(); onChange()
            })
        }
        if (app.pkg in dock) {
            DropdownMenuItem(text = { Text("Remover do dock") }, onClick = {
                store.setDock(dock - app.pkg); onClose(); onChange()
            })
        } else if (dock.size < 5) {
            DropdownMenuItem(text = { Text("Adicionar ao dock") }, onClick = {
                store.setDock(dock + app.pkg); onClose(); onChange()
            })
        }
        DropdownMenuItem(text = { Text(if (isHidden) "Mostrar app" else "Ocultar app") }, onClick = {
            store.setHidden(app.pkg, !isHidden); onClose(); onChange()
        })
        DropdownMenuItem(text = { Text("Desinstalar") }, onClick = {
            onClose()
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        })
    }
}

@Composable
fun AppCell(app: AppInfo, index: Int, store: Store, onChange: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    var menu by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Column(
        Modifier.padding(vertical = 8.dp)
            .reveal(shown, (index % 16) * 35, 40f)
            .bounceClick(onLong = { menu = true }) { launchApp(ctx, app.pkg) },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app.pkg, 52.dp)
        Text(app.label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = pal.text)
        AppMenu(menu, { menu = false }, app, store, onChange)
    }
}

@Composable
fun DockIcon(app: AppInfo, index: Int, started: Boolean, store: Store, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier.reveal(started, 350 + index * 80, 120f)
            .bounceClick(onLong = { menu = true }) { launchApp(ctx, app.pkg) }
    ) {
        AppIcon(app.pkg, 50.dp)
        AppMenu(menu, { menu = false }, app, store, onChange)
    }
}

@Composable
fun Dock(apps: List<AppInfo>, started: Boolean, store: Store, onChange: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            .reveal(started, 200, 220f)
            .fillMaxWidth().height(78.dp)
            .shadow(10.dp, RoundedCornerShape(30.dp), clip = false)
            .clip(RoundedCornerShape(30.dp)).background(pal.card)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (apps.isEmpty()) {
            Text("Segure um app e escolha \"Adicionar ao dock\"", fontSize = 12.sp, color = pal.sub)
        }
        apps.forEachIndexed { i, a -> DockIcon(a, i, started, store, onChange) }
    }
}

@Composable
fun Dots(page: Int) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center) {
        for (i in 0..1) {
            val w by animateDpAsState(
                if (page == i) 20.dp else 6.dp,
                spring(Spring.DampingRatioMediumBouncy), label = "w"
            )
            val col by animateColorAsState(
                if (page == i) pal.accent else pal.sub.copy(alpha = 0.4f), label = "c"
            )
            Box(Modifier.padding(horizontal = 3.dp).height(6.dp).width(w).clip(CircleShape).background(col))
        }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    val bg by animateColorAsState(if (selected) pal.accent else pal.card, tween(250), label = "bg")
    val fg by animateColorAsState(if (selected) pal.onAccent else pal.text, tween(250), label = "fg")
    val sc by animateFloatAsState(
        if (selected) 1.06f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "sc"
    )
    Box(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc }
            .bounceClick(onClick = onClick)
            .clip(RoundedCornerShape(50)).background(bg)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(label, color = fg, fontSize = 13.sp) }
}

@Composable
fun Panel(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Column(
        modifier.fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(28.dp), clip = false)
            .clip(RoundedCornerShape(28.dp)).background(pal.card).padding(18.dp),
        content = content
    )
}

@Composable
fun MusicBody(m: Music) {
    val pal = LocalPal.current
    val inf = rememberInfiniteTransition(label = "inf")
    val pulse = inf.animateFloat(
        1f, 1.06f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val amp = animateFloatAsState(if (m.playing) 1f else 0f, tween(400), label = "amp")
    val prog = animateFloatAsState(
        if (m.dur > 0) (m.pos.toFloat() / m.dur).coerceIn(0f, 1f) else 0f,
        tween(1000, easing = LinearEasing), label = "prog"
    )
    val tc = m.controller.transportControls
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(84.dp)
                .graphicsLayer {
                    val s = 1f + (pulse.value - 1f) * amp.value
                    scaleX = s; scaleY = s
                }
                .clip(RoundedCornerShape(20.dp)).background(pal.sub.copy(alpha = 0.2f))
        ) {
            m.art?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Crossfade(targetState = m.title, label = "title") { t ->
                Text(t, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = pal.text)
            }
            Text(m.artist, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = pal.sub)
        }
    }
    Spacer(Modifier.height(16.dp))
    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.sub.copy(alpha = 0.25f))) {
        Box(Modifier.fillMaxWidth(prog.value).fillMaxHeight().background(pal.accent))
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth()) {
        Text(fmt(m.pos), fontSize = 11.sp, color = pal.sub)
        Spacer(Modifier.weight(1f))
        Text(fmt(m.dur), fontSize = 11.sp, color = pal.sub)
    }
    Spacer(Modifier.height(10.dp))
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.bounceClick { tc.skipToPrevious() }.padding(10.dp)) { Glyph(3, 24.dp, pal.text) }
        Box(
            Modifier.size(56.dp).bounceClick { if (m.playing) tc.pause() else tc.play() }
                .clip(CircleShape).background(pal.accent),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = m.playing, label = "pp") { p ->
                Glyph(if (p) 1 else 0, 22.dp, pal.onAccent)
            }
        }
        Box(Modifier.bounceClick { tc.skipToNext() }.padding(10.dp)) { Glyph(2, 24.dp, pal.text) }
    }
}

@Composable
fun Pill(text: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier.bounceClick(onClick = onClick)
            .clip(RoundedCornerShape(50)).background(bg)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) { Text(text, color = fg, fontSize = 13.sp) }
}

@Composable
fun Swatch(fill: Color, inner: Color?, selected: Boolean, label: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    val sc by animateFloatAsState(
        if (selected) 1.15f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "sw"
    )
    Column(
        Modifier.width(56.dp).bounceClick(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(40.dp).graphicsLayer { scaleX = sc; scaleY = sc }
                .border(
                    if (selected) 3.dp else 1.dp,
                    if (selected) pal.accent else pal.sub.copy(alpha = 0.4f), CircleShape
                )
                .padding(4.dp).clip(CircleShape).background(fill),
            contentAlignment = Alignment.Center
        ) {
            if (inner != null) Box(Modifier.size(14.dp).clip(CircleShape).background(inner))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 10.sp, color = pal.sub, maxLines = 1)
    }
}

@Composable
fun SettingsSheet(
    themeIdx: Int, accentOv: Int, dim: Float, hasWall: Boolean,
    onTheme: (Int) -> Unit, onAccent: (Int) -> Unit, onDim: (Float) -> Unit,
    onPickWall: () -> Unit, onClearWall: () -> Unit, onReset: () -> Unit, onClose: () -> Unit
) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(pal.card.copy(alpha = 1f))
            .navigationBarsPadding()
            .heightIn(max = 560.dp)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Personalizar", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = pal.text, modifier = Modifier.weight(1f))
            Pill("Fechar", pal.sub.copy(alpha = 0.2f), pal.text, onClose)
        }
        Spacer(Modifier.height(18.dp))
        Text("Wallpaper (imagem, GIF ou vídeo)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = pal.text)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Escolher arquivo", pal.accent, pal.onAccent, onPickWall)
            if (hasWall) Pill("Remover", pal.sub.copy(alpha = 0.2f), pal.text, onClearWall)
        }
        if (hasWall) {
            Spacer(Modifier.height(10.dp))
            Text("Escurecer fundo", fontSize = 12.sp, color = pal.sub)
            Slider(
                value = dim, onValueChange = onDim, valueRange = 0f..0.9f,
                colors = SliderDefaults.colors(
                    thumbColor = pal.accent, activeTrackColor = pal.accent,
                    inactiveTrackColor = pal.sub.copy(alpha = 0.3f)
                )
            )
        }
        Spacer(Modifier.height(14.dp))
        Text("Tema", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = pal.text)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            THEMES.forEachIndexed { i, t -> Swatch(t.bg, t.accent, i == themeIdx, t.name) { onTheme(i) } }
        }
        Spacer(Modifier.height(14.dp))
        Text("Cor de destaque", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = pal.text)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Swatch(pal.sub.copy(alpha = 0.2f), null, accentOv == 0, "Auto") { onAccent(0) }
            ACCENTS.forEach { c -> Swatch(c, null, accentOv == c.toArgb(), "") { onAccent(c.toArgb()) } }
        }
        Spacer(Modifier.height(16.dp))
        Pill("Restaurar padrão", pal.sub.copy(alpha = 0.2f), pal.text, onReset)
    }
}

@Composable
fun MusicCard(modifier: Modifier) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val ui by rememberMusic(ctx)
    Panel(modifier) {
        val m = ui.music
        if (!ui.granted) {
            Text("Mostrar a música que está tocando", fontSize = 15.sp,
                fontWeight = FontWeight.Bold, color = pal.text)
            Spacer(Modifier.height(4.dp))
            Text("Libere o acesso às notificações para o launcher ler o player.",
                fontSize = 12.sp, color = pal.sub)
            Spacer(Modifier.height(12.dp))
            Pill("Permitir acesso", pal.accent, pal.onAccent) {
                ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        } else if (m == null) {
            Text("Nada tocando agora", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = pal.text)
            Text("Abra um player de música e ele aparece aqui.", fontSize = 12.sp, color = pal.sub)
        } else {
            MusicBody(m)
        }
    }
}

@Composable
fun Day(d: Int, isToday: Boolean, visible: Boolean, idx: Int) {
    val pal = LocalPal.current
    val s = animateFloatAsState(
        if (visible) 1f else 0f,
        tween(500, delayMillis = 150 + idx * 14, easing = EASE_BACK), label = "d"
    )
    val pulse = if (isToday) {
        rememberInfiniteTransition(label = "t").animateFloat(
            1f, 1.12f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "tp"
        ).value
    } else 1f
    Box(
        Modifier.fillMaxSize().padding(2.dp)
            .graphicsLayer {
                val k = s.value * pulse
                scaleX = k; scaleY = k; alpha = s.value.coerceIn(0f, 1f)
            }
            .clip(CircleShape).background(if (isToday) pal.accent else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        Text("$d", fontSize = 12.sp, color = if (isToday) pal.onAccent else pal.text)
    }
}

@Composable
fun CalendarCard(visible: Boolean, modifier: Modifier) {
    val pal = LocalPal.current
    val today = remember { LocalDate.now() }
    val offset = today.withDayOfMonth(1).dayOfWeek.value % 7
    val n = today.lengthOfMonth()
    val rows = (offset + n + 6) / 7
    val title = today.month.getDisplayName(JTextStyle.FULL, Locale("pt", "BR")).uppercase() + " " + today.year
    Panel(modifier) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = pal.text)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            listOf("D", "S", "T", "Q", "Q", "S", "S").forEach {
                Text(it, modifier = Modifier.weight(1f), textAlign = TextAlign.Center,
                    fontSize = 11.sp, color = pal.sub)
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0..6) {
                    val d = r * 7 + c - offset + 1
                    Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
                        if (d in 1..n) Day(d, d == today.dayOfMonth, visible, r * 7 + c)
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetsPage(visible: Boolean) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        MusicCard(Modifier.reveal(visible, 0))
        CalendarCard(visible, Modifier.reveal(visible, 120))
        Spacer(Modifier.height(8.dp))
    }
}

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val lock = mutableIntStateOf(0)
    private val active = mutableStateOf(true)
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { tick.intValue++ }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        setContent { MaterialTheme(colorScheme = lightColorScheme()) { Home(tick.intValue, lock.intValue, active.value) } }
    }

    override fun onStart() {
        super.onStart()
        active.value = true
    }

    override fun onStop() {
        active.value = false
        lock.intValue++
        super.onStop()
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}

@Composable
fun PinKey(k: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(Modifier.padding(6.dp).size(64.dp), contentAlignment = Alignment.Center) {
        if (k.isNotEmpty()) {
            Box(
                Modifier.fillMaxSize().bounceClick(onClick = onClick)
                    .clip(CircleShape).background(pal.sub.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) { Text(if (k == "<") "←" else k, fontSize = 22.sp, color = pal.text) }
        }
    }
}

@Composable
fun PinDialog(correct: String, onOk: () -> Unit, onCancel: () -> Unit) {
    val pal = LocalPal.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    val shake = remember { Animatable(0f) }

    fun press(d: String) {
        if (code.length >= correct.length) return
        code += d
        if (code.length == correct.length) {
            if (code == correct) {
                onOk()
            } else {
                code = ""
                scope.launch {
                    shake.animateTo(0f, keyframes {
                        durationMillis = 400
                        -18f at 60
                        18f at 160
                        -12f at 260
                        8f at 340
                    })
                }
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
        ) { onCancel() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.graphicsLayer { translationX = shake.value }
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .clip(RoundedCornerShape(32.dp)).background(pal.card.copy(alpha = 1f)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Área oculta", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = pal.text)
            Text("Digite a senha", fontSize = 13.sp, color = pal.sub)
            Spacer(Modifier.height(14.dp))
            Row {
                repeat(correct.length) { i ->
                    val on = i < code.length
                    val sc by animateFloatAsState(
                        if (on) 1.25f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "pd"
                    )
                    Box(
                        Modifier.padding(7.dp).size(14.dp)
                            .graphicsLayer { scaleX = sc; scaleY = sc }
                            .clip(CircleShape)
                            .background(if (on) pal.accent else pal.sub.copy(alpha = 0.3f))
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            listOf(
                listOf("1", "2", "3"), listOf("4", "5", "6"),
                listOf("7", "8", "9"), listOf("", "0", "<")
            ).forEach { row ->
                Row {
                    row.forEach { k ->
                        PinKey(k) { if (k == "<") code = code.dropLast(1) else press(k) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Pill("Cancelar", pal.sub.copy(alpha = 0.2f), pal.text, onCancel)
        }
    }
}

@Composable
fun Home(tick: Int, lockTick: Int, active: Boolean) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var rev by remember { mutableIntStateOf(0) }
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var tab by remember { mutableStateOf(CATS[0]) }
    var secret by remember { mutableStateOf(false) }
    var taps by remember { mutableIntStateOf(0) }
    var centerKind by remember { mutableStateOf(store.kind("center")) }
    var wallKind by remember { mutableStateOf(store.kind("wall")) }
    var centerRev by remember { mutableIntStateOf(0) }
    var wallRev by remember { mutableIntStateOf(0) }
    var started by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var askPin by remember { mutableStateOf(false) }
    var themeIdx by remember { mutableIntStateOf(store.theme()) }
    var accentOv by remember { mutableIntStateOf(store.accent()) }
    var dim by remember { mutableFloatStateOf(store.dim()) }
    val clockFmt = remember { DateTimeFormatter.ofPattern("HH:mm") }
    var time by remember { mutableStateOf(LocalTime.now().format(clockFmt)) }
    val dateStr = remember(time) {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("pt", "BR")))
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val k = withContext(Dispatchers.IO) { saveMedia(ctx, uri, "center") }
            store.setKind("center", k); centerKind = k; centerRev++
        }
    }
    val wallPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val k = withContext(Dispatchers.IO) { saveMedia(ctx, uri, "wall") }
            store.setKind("wall", k); wallKind = k; wallRev++
        }
    }

    val base = THEMES[themeIdx.coerceIn(0, THEMES.size - 1)]
    val acc = if (accentOv != 0) Color(accentOv) else base.accent
    val target = base.copy(
        accent = acc,
        onAccent = if (acc.luminance() > 0.5f) Color(0xFF111111) else Color.White,
        card = if (wallKind.isNotEmpty()) base.card.copy(alpha = 0.88f) else base.card
    )
    val pal = animPal(target)

    SideEffect {
        val c = WindowCompat.getInsetsController((ctx as Activity).window, ctx.window.decorView)
        val light = base.bg.luminance() > 0.5f
        c.isAppearanceLightStatusBars = light
        c.isAppearanceLightNavigationBars = light
    }

    LaunchedEffect(Unit) { started = true }
    LaunchedEffect(lockTick) {
        if (lockTick > 0) { secret = false; askPin = false; if (tab == HIDDEN) tab = CATS[0] }
    }
    LaunchedEffect(tick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(Unit) {
        while (true) { time = LocalTime.now().format(clockFmt); delay(20_000) }
    }

    val pager = rememberPagerState(pageCount = { 2 })
    BackHandler(pager.currentPage == 1) { scope.launch { pager.animateScrollToPage(0) } }
    BackHandler(secret && pager.currentPage == 0) { secret = false; if (tab == HIDDEN) tab = CATS[0] }
    BackHandler(showSettings) { showSettings = false }
    BackHandler(askPin) { askPin = false }

    val hidden = remember(rev, apps) { store.hidden() }
    val dockApps = remember(rev, apps) { store.dock().mapNotNull { p -> apps.firstOrNull { it.pkg == p } } }
    val list = remember(apps, tab, rev, hidden) {
        apps.filter { a ->
            when (tab) {
                HIDDEN -> a.pkg in hidden
                OTHERS -> a.pkg !in hidden && store.cat(a.pkg) == null
                else -> a.pkg !in hidden && store.cat(a.pkg) == tab
            }
        }
    }

    val pop = animateFloatAsState(
        if (started) 1f else 0f,
        spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow), label = "pop"
    )
    val inf = rememberInfiniteTransition(label = "float")
    val floatY = inf.animateFloat(
        -6f, 6f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "fy"
    )

    CompositionLocalProvider(LocalPal provides pal) {
        Box(
            Modifier.fillMaxSize().background(pal.bg)
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { if (!Guard.pressing && !askPin) showSettings = true })
                }
        ) {
            Crossfade(targetState = wallKind to wallRev, label = "wall") { (k, r) ->
                if (k.isNotEmpty()) MediaView("wall.bin", k, r, active, Modifier.fillMaxSize())
            }
            if (wallKind.isNotEmpty()) Box(Modifier.fillMaxSize().background(pal.bg.copy(alpha = dim)))

            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                    val off = (pager.currentPage - page) + pager.currentPageOffsetFraction
                    Box(
                        Modifier.fillMaxSize().graphicsLayer {
                            val a = abs(off).coerceIn(0f, 1f)
                            alpha = 1f - a * 0.6f
                            scaleX = 1f - a * 0.1f
                            scaleY = 1f - a * 0.1f
                            translationX = off * size.width * 0.2f
                        }
                    ) {
                        if (page == 0) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    time, fontSize = 48.sp, fontWeight = FontWeight.Black, color = pal.text,
                                    modifier = Modifier.reveal(started, 0, -40f).clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        taps++
                                        if (taps >= 5) { taps = 0; if (secret) tab = HIDDEN else askPin = true }
                                    }
                                )
                                Text(dateStr, fontSize = 13.sp, color = pal.sub,
                                    modifier = Modifier.reveal(started, 80, -30f))
                                Spacer(Modifier.height(10.dp))
                                Box(
                                    Modifier.fillMaxWidth().height(170.dp)
                                        .graphicsLayer {
                                            scaleX = pop.value; scaleY = pop.value
                                            alpha = pop.value.coerceIn(0f, 1f)
                                            translationY = floatY.value
                                        }
                                        .bounceClick { picker.launch(arrayOf("image/*", "video/*")) }
                                        .clip(RoundedCornerShape(32.dp)).background(pal.card),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (centerKind.isNotEmpty()) {
                                        MediaView("center.bin", centerKind, centerRev, active, Modifier.fillMaxSize())
                                    } else Text("Toque para\nescolher foto", color = pal.sub,
                                        fontSize = 13.sp, textAlign = TextAlign.Center)
                                }
                                Spacer(Modifier.height(14.dp))

                                val tabs = CATS + OTHERS + if (secret) listOf(HIDDEN) else emptyList()
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    itemsIndexed(tabs) { i, t ->
                                        Chip(t, tab == t, Modifier.reveal(started, 200 + i * 50, 30f)) { tab = t }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))

                                LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
                                    itemsIndexed(list, key = { _, a -> a.pkg }) { i, app ->
                                        AppCell(app, i, store) { rev++ }
                                    }
                                }
                            }
                        } else {
                            WidgetsPage(visible = pager.currentPage == 1)
                        }
                    }
                }
                Dots(pager.currentPage)
                Dock(dockApps, started, store) { rev++ }
            }

            AnimatedVisibility(
                visible = showSettings,
                enter = fadeIn(tween(250)), exit = fadeOut(tween(200))
            ) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable(
                        interactionSource = remember { MutableInteractionSource() }, indication = null
                    ) { showSettings = false }
                )
            }
            AnimatedVisibility(
                visible = showSettings,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(
                    animationSpec = spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow),
                    initialOffsetY = { it }
                ),
                exit = slideOutVertically(animationSpec = tween(250), targetOffsetY = { it })
            ) {
                SettingsSheet(
                    themeIdx = themeIdx, accentOv = accentOv, dim = dim, hasWall = wallKind.isNotEmpty(),
                    onTheme = { i -> themeIdx = i; store.setTheme(i) },
                    onAccent = { v -> accentOv = v; store.setAccent(v) },
                    onDim = { v -> dim = v; store.setDim(v) },
                    onPickWall = { wallPicker.launch(arrayOf("image/*", "video/*")) },
                    onClearWall = { File(ctx.filesDir, "wall.bin").delete(); store.setKind("wall", ""); wallKind = "" },
                    onReset = {
                        themeIdx = 0; store.setTheme(0)
                        accentOv = 0; store.setAccent(0)
                        dim = 0.35f; store.setDim(0.35f)
                        File(ctx.filesDir, "wall.bin").delete(); store.setKind("wall", ""); wallKind = ""
                    },
                    onClose = { showSettings = false }
                )
            }
            AnimatedVisibility(
                visible = askPin,
                enter = fadeIn(tween(200)) + scaleIn(spring(Spring.DampingRatioMediumBouncy), 0.85f),
                exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.9f)
            ) {
                PinDialog(
                    correct = store.pin(),
                    onOk = { askPin = false; secret = true; tab = HIDDEN },
                    onCancel = { askPin = false }
                )
            }
        }
    }
}
